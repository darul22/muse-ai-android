MUSE AI ANDROID — PANDUAN BUILD APK DARI HP

PENTING:
- ZIP ini adalah proyek sumber, bukan APK jadi.
- Cara paling praktis dari HP adalah mengunggah ZIP ke repo GitHub lalu menjalankan GitHub Actions.
- Jangan pernah memasukkan API key Meta ke aplikasi Android atau membagikannya di chat.

LANGKAH 1 — BUAT REPOSITORY
1. Login ke https://github.com
2. Tekan tombol + lalu New repository.
3. Nama repository: muse-ai-android
4. Pilih Public (agar GitHub Actions gratis untuk repo publik), lalu Create repository.

LANGKAH 2 — UNGGAH ZIP PROYEK
1. Buka repository yang baru dibuat.
2. Pilih Add file > Upload files.
3. Unggah file MUSE-AI-ANDROID-SOURCE.zip (jangan diekstrak lagi).
4. Tekan Commit changes.

LANGKAH 3 — BUAT WORKFLOW
1. Di repository pilih Add file > Create new file.
2. Nama file persis: .github/workflows/android.yml
3. Isi file dengan YAML berikut (salin dari file BUILD-WORKFLOW.txt yang disertakan dalam ZIP).
4. Tekan Commit changes.

LANGKAH 4 — JALANKAN BUILD
1. Buka tab Actions.
2. Pilih Build MUSE AI APK.
3. Tekan Run workflow > Run workflow.
4. Tunggu hingga selesai (centang hijau).
5. Buka hasil workflow, cari Artifacts, unduh muse-ai-debug-apk.zip.
6. Ekstrak ZIP tersebut dan pasang app-debug.apk di HP.

LANGKAH 5 — HUBUNGKAN BACKEND
Aplikasi perlu Worker API yang kompatibel pada endpoint /api/chat. Konfigurasikan alamat Worker melalui ikon ⚙ di aplikasi. API key Meta harus disimpan sebagai secret di backend, bukan di APK.

Jika GitHub tidak menerima ZIP atau tombol Upload files tidak terlihat, kirim tangkapan layar (sembunyikan email dan informasi pribadi) agar langkahnya bisa disesuaikan.
